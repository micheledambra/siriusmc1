//
//  TasksInGoal.swift
//  siriusmc1
//
//  Created by Aleksandra Nikiforova on 21/10/22.
//

import SwiftUI

struct TasksInGoal: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct TasksInGoal_Previews: PreviewProvider {
    static var previews: some View {
        TasksInGoal()
    }
}
