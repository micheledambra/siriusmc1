//
//  siriusmc1App.swift
//  siriusmc1
//
//  Created by Michele D'Ambra on 20/10/22.
//

import SwiftUI

@main
struct siriusmc1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
